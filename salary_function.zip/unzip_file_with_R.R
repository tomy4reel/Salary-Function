# Unzipping the file
unzip("Employee_Profile.zip", exdir = "Employee_Profile")

# Reading and displaying the CSV file
employee_data <- read.csv("Employee_Profile/PATRICK_GARDNER.csv")
print(employee_data)
